# Panduan Deploy WebGIS Kabupaten Luwu ke Infinityfree

Panduan ini untuk meng-upload WebGIS yang sudah dilengkapi sistem login & role (admin/user) ke hosting gratis **Infinityfree**.

---

## 0. Yang Sudah Ditambahkan ke Project Kamu

| File/Folder | Fungsi |
|---|---|
| `config.php` | Koneksi ke database — **SATU-SATUNYA file yang wajib kamu edit** |
| `database.sql` | Struktur tabel database (import lewat phpMyAdmin) |
| `setup_admin.php` | Buat akun admin pertama (jalankan sekali, lalu **hapus**) — sekarang otomatis terkunci kalau admin sudah ada |
| `login.php` | Halaman & proses login |
| `logout.php` | Proses logout |
| `auth.php` | Pengaman session (dipanggil otomatis oleh halaman lain) |
| `index.php` | Peta utama (dulu `index.html`) — sekarang wajib login, ada info user & tombol logout |
| `admin/dashboard.php` | Kelola user: tambah, reset password, nonaktifkan, hapus |
| `admin/kelola_layer.php` | Upload ulang file GeoJSON untuk mengganti data peta |
| `.htaccess` | Blokir akses publik ke file `.sql`, `.md`, dan file backup lewat URL langsung |

**Cara kerja login & role:**
- **Admin**: bisa lihat peta + akses Dashboard Admin (kelola user & layer)
- **User biasa**: hanya bisa lihat peta, tombol admin disembunyikan otomatis
- **Tamu** (opsional): bisa lihat peta tanpa login lewat link "Lihat sebagai tamu" di halaman login, hanya untuk keperluan demo ke dosen penguji

---

## 0.1 Perbaikan yang Sudah Dilakukan (Update)

Beberapa bug dan risiko keamanan sudah diperbaiki supaya project ini aman dan siap di-hosting:

| Perbaikan | Detail |
|---|---|
| **Bug kritis di `setup_admin.php`** | Sebelumnya, pengecekan "apakah admin sudah ada" salah tipe data (`"0" === 0` selalu `false` di PHP), sehingga form bisa error/tidak konsisten. Sudah diperbaiki dengan cast `(int)`. |
| **Form `setup_admin.php` sekarang terkunci otomatis** | Kalau sudah ada 1 admin saja, form submit langsung ditolak server (bukan cuma peringatan di tampilan). Jadi kalau kamu lupa hapus file ini, orang lain tidak bisa membuat admin baru. **Tetap disarankan hapus file ini setelah dipakai.** |
| **Query SQL di `dashboard.php` (toggle status user)** | Sebelumnya pakai penggabungan string langsung ke query SQL. Sudah diganti ke *prepared statement* (lebih aman, standar praktik baik). |
| **File `.htaccess` baru** | Mencegah `database.sql`, file ini (`.md`), dan file backup `*.backup-*` diakses langsung lewat URL browser siapa pun. |
| **Folder `geojesoon1/` dihapus** | Berisi data GeoJSON mentah (~11MB) yang sudah "dibungkus" jadi file `.js` di folder `js/`. Folder ini duplikat dan **tidak pernah dipakai** oleh kode manapun — menghapusnya menghemat ~50% ukuran upload, penting karena hosting gratis biasanya punya kuota terbatas. |
| **File duplikat/sisa dihapus** | `css/style.css` (tidak dipakai, style sudah inline di `index.php`), `js/main.js` (skrip versi lama, sudah digantikan skrip inline di `index.php`), `libs/pemerintahan/icon copy.jpg` (duplikat dari `icon.jpg`). |
| **File data GeoJSON dikompresi** | Presisi koordinat dipangkas dari ~14 digit desimal jadi 6 digit (setara akurasi ~11cm — tidak terlihat kasat mata di peta web), plus JSON di-minify (hapus spasi/baris baru berlebih). `js/luwu.js` turun dari **7.4MB → 4.0MB**. Lihat tabel detail di bawah. |

### Detail Ukuran File Setelah Kompresi

| File | Ukuran Sebelum | Ukuran Sesudah | Hemat |
|---|---|---|---|
| `js/luwu.js` | 7.4 MB | 4.0 MB | ~46% |
| `js/jalan.js` | 2.1 MB | 1.3 MB | ~42% |
| `js/administrasikecamatan.js` | 0.74 MB | 0.42 MB | ~44% |
| `js/belopa.js` | 0.31 MB | 0.25 MB | ~22% |
| `js/pegawai.js` | 0.07 MB | 0.06 MB | ~23% |
| `js/pemerintahan.js` | 0.04 MB | 0.03 MB | ~19% |

> 📌 **Soal limit ukuran file di Infinityfree** (resmi dari dokumentasi mereka):
> - File **`.html` dan `.php`**: maksimal **1 MB** (semua file `.php` di project ini jauh di bawah itu, terbesar `index.php` ~25KB — aman)
> - File **`.htaccess`**: maksimal **10 KB** (file `.htaccess` project ini ~672 bytes — aman)
> - File lain (termasuk **`.js`**, gambar): maksimal **10 MB**
>
> Setelah kompresi, `js/luwu.js` (file terbesar) sekarang 4.0MB — jauh di bawah batas 10MB, sehingga risiko upload gagal/terpotong jauh lebih kecil dibanding sebelumnya yang nyaris menyentuh limit (7.4MB).

> ℹ️ File `js/belopa.js`, `js/jalan.js`, `js/pemerintahan.js`, `js/administrasikecamatan.js`, `js/labels.js` **dibiarkan ada** meski belum dipakai di `index.php` saat ini (siapa tahu kamu ingin menambahkannya sebagai layer baru nanti). Tidak mempengaruhi jalannya peta utama.

---

## 1. Daftar & Siapkan Hosting

1. Daftar di [infinityfree.net](https://infinityfree.net) (gratis, tidak perlu kartu kredit)
2. Buat akun hosting baru, catat domain/subdomain yang kamu dapat (misalnya `namamu.infinityfreeapp.com`)
3. Tunggu status hosting menjadi **Active** (biasanya beberapa menit setelah daftar)

---

## 2. Buat Database MySQL

1. Login ke **Client Area** Infinityfree → menu **Accounts** → klik akun hosting kamu → klik tombol **Control Panel** (ini membuka VistaPanel, mirip cPanel)
2. Di VistaPanel, cari & klik menu **MySQL Databases**
3. Di kolom **New Database**, isi nama pendek (misal `webgis`), klik **Create Database**
4. Tunggu beberapa detik sampai database baru muncul di bagian **Current Databases**, lalu catat baik-baik 3 hal ini (klik/lihat langsung di baris database kamu — **jangan menebak atau mengetik manual**, copy-paste langsung):
   - **MySQL Host Name** → contoh: `sql200.infinityfree.com`
   - **MySQL DB Name** → contoh: `if0_xxxxxxxx_webgis`
   - **MySQL User Name** → biasanya sama dengan DB Name, contoh: `if0_xxxxxxxx_webgis`

> 📌 **Soal prefix akun:** akun Infinityfree generasi terbaru memakai prefix `if0_` (contoh: `if0_38912345`). Kalau akun kamu generasi lama, prefix-nya bisa `epiz_`. Apapun prefix-nya, yang penting kamu **copy langsung dari VistaPanel kamu sendiri**, jangan pakai contoh format dari internet/tutorial lama — formatnya bisa beda-beda per akun.

5. **Untuk password database** — ini bagian yang paling sering bikin bingung:
   > ⚠️ **Database TIDAK punya password sendiri yang kamu buat baru.** Password untuk konek ke database **SAMA** dengan **password akun hosting** kamu (password yang kamu pakai untuk login ke Client Area Infinityfree).
   >
   > Cara melihatnya: di **Client Area** → klik akun hosting kamu → cari bagian **Account Password** → klik tombol **Show** → copy password yang muncul di sana. Itulah `DB_PASS` kamu.

> ⚠️ Catat ke-4 informasi ini (Host Name, DB Name, User Name, dan Account Password), nanti dibutuhkan di Langkah 4. Kalau baru saja membuat database, **tunggu 5-15 menit** dulu sebelum mencoba konek — kadang ada delay propagasi di sisi server Infinityfree.

---

## 3. Import Struktur Database

1. Masih di VistaPanel, buka **phpMyAdmin**
2. Pilih database yang baru kamu buat di sidebar kiri
3. Klik tab **Import** di bagian atas
4. Klik **Choose File**, pilih file `database.sql` dari project ini
5. Klik **Go** / **Import** di bagian bawah
6. Pastikan muncul pesan sukses dan terlihat 2 tabel baru: `users` dan `login_log`

---

## 4. Edit config.php

Buka file `config.php` di komputer kamu (pakai Notepad/VS Code), ganti 4 baris ini dengan data dari Langkah 2 — **copy-paste langsung**, jangan ketik manual:

```php
define('DB_HOST', 'sql200.infinityfree.com');       // ganti dengan MySQL Host Name kamu
define('DB_NAME', 'if0_xxxxxxxx_webgis');           // ganti dengan MySQL DB Name kamu
define('DB_USER', 'if0_xxxxxxxx_webgis');           // ganti dengan MySQL User Name kamu
define('DB_PASS', 'PASSWORD_AKUN_HOSTING_KAMU');    // ganti dengan password AKUN HOSTING (lihat Langkah 2 poin 5)
```

> 🔑 Ingat: `DB_PASS` itu **password akun hosting** kamu (yang sama dipakai login Client Area), **bukan** password baru yang kamu buat sendiri — karena memang tidak ada password terpisah untuk database di Infinityfree.

Simpan file. Kalau nanti koneksi gagal dan kamu butuh lihat detail error teknisnya untuk troubleshooting, ada baris tambahan di `config.php`:

```php
define('DEBUG_MODE', false);
```

Ubah sementara jadi `true` untuk melihat pesan error MySQL yang sebenarnya (misalnya "Access denied" atau "Unknown host"), lalu **kembalikan ke `false`** setelah masalah selesai — supaya detail teknis server tidak terlihat oleh pengunjung saat sudah live.

---

## 5. Upload File ke Server

Ada 2 cara — pilih salah satu:

### Cara A: File Manager (lebih mudah, cocok untuk file kecil)
1. Di VistaPanel, buka **File Manager**
2. Masuk ke folder **htdocs**
3. Upload semua file & folder project (kecuali `database.sql`, yang sudah dipakai di Langkah 3) — **termasuk file `.htaccess`** yang diawali titik (file ini tersembunyi secara default, pastikan ikut terupload, jangan terlewat)
4. Tunggu sampai semua selesai terupload

### Cara B: FTP dengan FileZilla (lebih cepat & andal untuk banyak file/file besar)
1. Download & install [FileZilla](https://filezilla-project.org/)
2. Di VistaPanel cari info **FTP Accounts** untuk dapat host, username, password FTP
3. Hubungkan FileZilla ke server, masuk ke folder `htdocs`
4. Aktifkan "Show hidden files" di FileZilla (menu Server) supaya `.htaccess` ikut ter-drag
5. Drag semua file & folder project ke folder `htdocs` di server

> ⚠️ **Penting:** Infinityfree membatasi ukuran file maksimal **10MB per file** untuk file non-PHP/HTML (lihat detail limit di bagian 0.1 di atas), dan ini tidak bisa diubah. File `js/luwu.js` di project kamu sekarang berukuran sekitar 4MB (sudah dikompresi) — ini **aman dengan ruang lega**, tapi tetap disarankan:
> - Gunakan FTP (Cara B) untuk file ini, lebih andal daripada File Manager untuk file berukuran beberapa MB
> - Setelah upload, **buka kembali file itu di File Manager** untuk pastikan ukurannya sama dengan aslinya (kadang upload "kelihatan sukses" tapi file terpotong tanpa pesan error)

---

## 6. Buat Akun Admin Pertama

1. Buka browser, kunjungi: `https://domainmu.com/setup_admin.php`
2. Isi nama lengkap, username, dan password untuk akun admin pertamamu
3. Klik **Buat Akun Admin**
4. Setelah berhasil, **langsung hapus file `setup_admin.php`** dari server (lewat File Manager) — ini penting supaya orang lain tidak bisa membuat akun admin sembarangan

---

## 7. Tes Login

1. Buka `https://domainmu.com/login.php`
2. Login dengan akun admin yang baru dibuat
3. Kamu akan diarahkan ke Dashboard Admin
4. Klik **Lihat Peta** untuk cek peta utama tampil normal dengan navbar baru (info user + tombol logout)
5. Coba buat 1 akun user biasa lewat Dashboard Admin, lalu coba login dengan akun itu — pastikan tombol "Dashboard Admin" tidak muncul untuk role user

---

## 8. Checklist Keamanan Sebelum Sidang/Demo

- [ ] File `setup_admin.php` sudah dihapus dari server (atau minimal sudah ada 1 admin, sehingga form otomatis terkunci)
- [ ] `DEBUG_MODE` di `config.php` sudah dikembalikan ke `false` (kalau sempat diaktifkan saat troubleshooting)
- [ ] Password akun admin sudah diganti dari yang dipakai saat testing
- [ ] Sudah dicoba login sebagai admin DAN sebagai user biasa
- [ ] File `.htaccess` sudah ikut terupload ke folder `htdocs` (cek dengan File Manager, file ini "tersembunyi" karena diawali titik — aktifkan "Show Hidden Files" kalau tidak terlihat)

---

## Troubleshooting Umum

| Masalah | Kemungkinan Sebab | Solusi |
|---|---|---|
| "Koneksi database gagal" | Salah satu dari 4 nilai di `config.php` tidak cocok | Ubah `DEBUG_MODE` jadi `true` di `config.php` untuk lihat pesan error MySQL asli, lalu cocokkan lagi 4 nilai dengan yang ada di VistaPanel → MySQL Databases. Jangan lupa kembalikan `DEBUG_MODE` ke `false` setelah selesai |
| Error spesifik "Access denied for user ... (using password: YES)" | `DB_PASS` salah — paling sering karena memakai password lain, bukan password akun hosting | Pastikan `DB_PASS` = password **akun hosting** (Client Area → akun kamu → Account Password → Show), bukan password yang "terasa seperti" password database |
| Error "Unknown MySQL server host" | `DB_HOST` salah ketik, atau database baru belum selesai di-provision | Copy ulang `MySQL Host Name` langsung dari VistaPanel (jangan ketik manual). Kalau baru saja membuat database, tunggu 5-15 menit lalu coba lagi |
| Error "Unknown database" | `DB_NAME` salah, atau prefix akun beda (`if0_` vs `epiz_`) | Copy ulang `MySQL DB Name` persis dari VistaPanel — jangan menebak prefix berdasarkan tutorial/contoh dari internet |
| Peta blank setelah login | File `js/luwu.js` gagal terupload penuh | Upload ulang lewat FTP, cek ukuran file (~4MB) sama dengan aslinya di File Manager |
| Tidak bisa upload lewat panel "Kelola Data Layer" | File di atas 7MB, dibatasi panel upload web (bukan limit Infinityfree) | Upload manual via FTP ke folder `js/` (lihat petunjuk di halaman itu) |
| Halaman putih kosong (blank page) | Ada error PHP tapi disembunyikan | Ubah `DEBUG_MODE` jadi `true` di `config.php` untuk melihat error aslinya, lalu kembalikan ke `false` setelah selesai debug |
