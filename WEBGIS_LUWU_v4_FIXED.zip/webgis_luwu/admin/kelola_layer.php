<?php
require_once '../auth.php';
requireRole('admin');

$user = currentUser();
$pesan = '';
$pesanTipe = 'success';

// Mapping layer yang boleh diganti -> nama variabel JS & nama file tujuan
$layerMap = [
    'kecamatan' => ['file' => '../js/luwu.js',    'var' => 'luwudata',   'label' => 'Batas Wilayah Kecamatan'],
    'pegawai'   => ['file' => '../js/pegawai.js', 'var' => 'pegawaidata','label' => 'Lokasi Pegawai'],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['layer_key'])) {
    $key = $_POST['layer_key'];

    if (!isset($layerMap[$key])) {
        $pesan = 'Layer tidak dikenali.'; $pesanTipe = 'error';
    } elseif (!isset($_FILES['file_geojson']) || $_FILES['file_geojson']['error'] !== UPLOAD_ERR_OK) {
        if (($_FILES['file_geojson']['error'] ?? '') === UPLOAD_ERR_INI_SIZE) {
            $pesan = 'File terlalu besar untuk diupload lewat form ini (batas server). Gunakan FTP / File Manager Infinityfree untuk file besar — lihat petunjuk di bawah.';
        } else {
            $pesan = 'File gagal diupload. Pastikan kamu memilih file .geojson.';
        }
        $pesanTipe = 'error';
    } elseif ($_FILES['file_geojson']['size'] > 7 * 1024 * 1024) {
        $pesan = 'File berukuran ' . round($_FILES['file_geojson']['size']/1024/1024, 1) . ' MB. Form upload ini hanya disarankan untuk file di bawah 7MB karena batas server hosting gratis. Untuk file besar, upload manual lewat FTP / File Manager Infinityfree — lihat petunjuk di bawah.';
        $pesanTipe = 'error';
    } else {
        $tmpPath = $_FILES['file_geojson']['tmp_name'];
        $namaAsli = $_FILES['file_geojson']['name'];
        $ext = strtolower(pathinfo($namaAsli, PATHINFO_EXTENSION));

        if ($ext !== 'geojson' && $ext !== 'json') {
            $pesan = 'Format file harus .geojson atau .json.'; $pesanTipe = 'error';
        } else {
            $isiFile = file_get_contents($tmpPath);
            $jsonData = json_decode($isiFile);

            if ($jsonData === null) {
                $pesan = 'File bukan GeoJSON yang valid (gagal parse JSON). Periksa kembali isi file.'; $pesanTipe = 'error';
            } elseif (!isset($jsonData->type) || $jsonData->type !== 'FeatureCollection') {
                $pesan = 'File valid sebagai JSON tetapi bukan GeoJSON FeatureCollection.'; $pesanTipe = 'error';
            } else {
                // Backup file lama dulu sebelum ditimpa
                $info = $layerMap[$key];
                $targetFile = $info['file'];
                if (file_exists($targetFile)) {
                    @copy($targetFile, $targetFile . '.backup-' . date('Ymd-His'));
                }

                // Bungkus ulang jadi format var namaVar = {...};
                $isiBaru = 'var ' . $info['var'] . ' = ' . $isiFile . ';';
                file_put_contents($targetFile, $isiBaru);

                $pesan = 'Layer "' . $info['label'] . '" berhasil diperbarui! File lama otomatis dicadangkan (backup).';
                $pesanTipe = 'success';
            }
        }
    }
}

// Info file saat ini
function infoFile($path) {
    if (!file_exists($path)) return ['ukuran' => '-', 'modifikasi' => '-'];
    return [
        'ukuran' => round(filesize($path) / 1024, 1) . ' KB',
        'modifikasi' => date('d M Y H:i', filemtime($path)),
    ];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Kelola Layer - WebGIS Luwu</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
<style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body { font-family:'Segoe UI',Arial,sans-serif; background:#f0f2f5; }
    #navbar { height:56px; background:linear-gradient(135deg,#1a3a5c,#2274b8); display:flex; align-items:center; justify-content:space-between; padding:0 20px; box-shadow:0 2px 8px rgba(0,0,0,.2); }
    #navbar .left { display:flex; align-items:center; gap:10px; color:white; font-weight:700; font-size:15px; }
    .nav-btn { background:rgba(255,255,255,.15); color:white; border:1px solid rgba(255,255,255,.3); border-radius:6px; padding:7px 14px; font-size:12.5px; text-decoration:none; display:flex; align-items:center; gap:6px; }
    .nav-btn:hover { background:rgba(255,255,255,.28); }
    .container { max-width:820px; margin:24px auto; padding:0 20px; }
    .alert { padding:11px 14px; border-radius:7px; font-size:13px; margin-bottom:18px; }
    .alert.success { background:#f0fdf4; color:#15803d; border:1px solid #bbf7d0; }
    .alert.error { background:#fef2f2; color:#b91c1c; border:1px solid #fecaca; }
    .panel { background:white; border-radius:10px; box-shadow:0 2px 8px rgba(0,0,0,.06); margin-bottom:20px; overflow:hidden; }
    .panel-header { padding:14px 18px; background:#f8fafc; border-bottom:1px solid #e8ecf0; font-weight:700; font-size:14px; color:#1a3a5c; display:flex; align-items:center; gap:8px; }
    .panel-body { padding:18px; }
    .info-row { display:flex; justify-content:space-between; font-size:12.5px; color:#64748b; margin-bottom:14px; background:#f8fafc; padding:9px 12px; border-radius:7px; }
    label { display:block; font-size:12.5px; font-weight:600; color:#374151; margin:10px 0 6px; }
    input[type=file] { width:100%; padding:9px; border:1px solid #d1d5db; border-radius:6px; font-size:13px; background:white; }
    .btn-primary { background:#2274b8; color:white; border:none; padding:10px 18px; border-radius:7px; font-size:13.5px; cursor:pointer; font-weight:600; margin-top:14px; }
    .btn-primary:hover { background:#1a5e94; }
    .warn { background:#fffbeb; color:#92400e; border:1px solid #fde68a; padding:10px 12px; border-radius:6px; font-size:12px; margin-bottom:16px; line-height:1.6; }
</style>
</head>
<body>

<nav id="navbar">
    <div class="left"><i class="fa fa-file-arrow-up"></i> Kelola Data Layer — WebGIS Luwu</div>
    <div style="display:flex;gap:8px;">
        <a href="dashboard.php" class="nav-btn"><i class="fa fa-arrow-left"></i> Dashboard</a>
        <a href="../index.php" class="nav-btn"><i class="fa fa-map"></i> Lihat Peta</a>
    </div>
</nav>

<div class="container">

    <?php if ($pesan): ?>
        <div class="alert <?= $pesanTipe ?>"><?= htmlspecialchars($pesan) ?></div>
    <?php endif; ?>

    <div class="warn">
        ⚠️ Mengganti file layer akan langsung menimpa tampilan peta untuk semua pengguna. File lama otomatis dicadangkan (backup) di folder <code>js/</code> dengan nama <code>*.backup-tanggal</code>, jadi kalau ada kesalahan kamu bisa minta bantuan untuk mengembalikannya lewat File Manager Infinityfree.
    </div>

    <?php foreach ($layerMap as $key => $info):
        $fi = infoFile($info['file']);
    ?>
    <div class="panel">
        <div class="panel-header"><i class="fa fa-layer-group"></i> <?= htmlspecialchars($info['label']) ?></div>
        <div class="panel-body">
            <div class="info-row">
                <span>Ukuran saat ini: <b><?= $fi['ukuran'] ?></b></span>
                <span>Terakhir diubah: <b><?= $fi['modifikasi'] ?></b></span>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="layer_key" value="<?= $key ?>">
                <label>Upload file GeoJSON baru untuk mengganti layer ini</label>
                <input type="file" name="file_geojson" accept=".geojson,.json" required>
                <button type="submit" class="btn-primary"><i class="fa fa-upload"></i> Ganti Layer</button>
            </form>
        </div>
    </div>
    <?php endforeach; ?>

    <div class="panel">
        <div class="panel-header"><i class="fa fa-circle-info"></i> Untuk File Besar (di atas 7MB)</div>
        <div class="panel-body" style="font-size:13px;color:#475569;line-height:1.8;">
            <p>Hosting gratis Infinityfree membatasi ukuran upload lewat form web. Untuk mengganti layer <b>Batas Wilayah Kecamatan</b> yang ukurannya besar, upload manual lewat:</p>
            <ol style="margin:10px 0 0 18px;">
                <li>Buka <b>File Manager</b> di cPanel Infinityfree (atau gunakan FTP seperti FileZilla)</li>
                <li>Masuk ke folder <code>htdocs/js/</code></li>
                <li>Siapkan file GeoJSON baru, lalu edit jadi format: <code>var luwudata = {...isi geojson...};</code></li>
                <li>Upload dan timpa file <code>luwu.js</code> yang lama</li>
            </ol>
        </div>
    </div>

</div>
</body>
</html>
