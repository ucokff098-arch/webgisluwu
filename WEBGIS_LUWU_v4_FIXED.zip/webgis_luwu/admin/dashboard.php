<?php
require_once '../auth.php';
requireRole('admin');

$user = currentUser();
$pesan = '';
$pesanTipe = 'success';

// ── HANDLE TAMBAH USER ──
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aksi']) && $_POST['aksi'] === 'tambah') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $nama     = trim($_POST['nama_lengkap'] ?? '');
    $role     = ($_POST['role'] ?? 'user') === 'admin' ? 'admin' : 'user';

    if ($username === '' || $password === '' || $nama === '') {
        $pesan = 'Semua field wajib diisi.'; $pesanTipe = 'error';
    } elseif (strlen($password) < 6) {
        $pesan = 'Password minimal 6 karakter.'; $pesanTipe = 'error';
    } else {
        $cek = $koneksi->prepare("SELECT id FROM users WHERE username = ?");
        $cek->bind_param('s', $username);
        $cek->execute();
        if ($cek->get_result()->num_rows > 0) {
            $pesan = 'Username sudah dipakai.'; $pesanTipe = 'error';
        } else {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $koneksi->prepare("INSERT INTO users (username, password, nama_lengkap, role) VALUES (?, ?, ?, ?)");
            $stmt->bind_param('ssss', $username, $hash, $nama, $role);
            $stmt->execute();
            $_SESSION['flash_pesan'] = 'User baru berhasil ditambahkan.';
            $_SESSION['flash_tipe'] = 'success';
            header('Location: dashboard.php');
            exit;
        }
    }
}

// ── HANDLE UBAH STATUS (aktif/nonaktif) ──
if (isset($_GET['toggle_status']) && ctype_digit($_GET['toggle_status'])) {
    $id = (int)$_GET['toggle_status'];
    if ($id !== (int)$user['id']) { // tidak boleh nonaktifkan diri sendiri
        $stmtToggle = $koneksi->prepare("UPDATE users SET status = IF(status='aktif','nonaktif','aktif') WHERE id = ?");
        $stmtToggle->bind_param('i', $id);
        $stmtToggle->execute();
        $_SESSION['flash_pesan'] = 'Status user diperbarui.';
        $_SESSION['flash_tipe'] = 'success';
    } else {
        $_SESSION['flash_pesan'] = 'Tidak bisa menonaktifkan akun sendiri.';
        $_SESSION['flash_tipe'] = 'error';
    }
    header('Location: dashboard.php');
    exit;
}

// ── HANDLE HAPUS USER ──
if (isset($_GET['hapus']) && ctype_digit($_GET['hapus'])) {
    $id = (int)$_GET['hapus'];
    if ($id !== (int)$user['id']) {
        $stmt = $koneksi->prepare("DELETE FROM users WHERE id = ?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $_SESSION['flash_pesan'] = 'User berhasil dihapus.';
        $_SESSION['flash_tipe'] = 'success';
    } else {
        $_SESSION['flash_pesan'] = 'Tidak bisa menghapus akun sendiri.';
        $_SESSION['flash_tipe'] = 'error';
    }
    header('Location: dashboard.php');
    exit;
}

// ── HANDLE RESET PASSWORD ──
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aksi']) && $_POST['aksi'] === 'reset_password') {
    $id = (int)$_POST['user_id'];
    $passwordBaru = $_POST['password_baru'] ?? '';
    if (strlen($passwordBaru) < 6) {
        $pesan = 'Password baru minimal 6 karakter.'; $pesanTipe = 'error';
    } else {
        $hash = password_hash($passwordBaru, PASSWORD_BCRYPT);
        $stmt = $koneksi->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->bind_param('si', $hash, $id);
        $stmt->execute();
        $_SESSION['flash_pesan'] = 'Password berhasil direset.';
        $_SESSION['flash_tipe'] = 'success';
        header('Location: dashboard.php');
        exit;
    }
}

// ── AMBIL PESAN FLASH (jika ada, dari redirect sebelumnya) ──
if (isset($_SESSION['flash_pesan'])) {
    $pesan = $_SESSION['flash_pesan'];
    $pesanTipe = $_SESSION['flash_tipe'] ?? 'success';
    unset($_SESSION['flash_pesan'], $_SESSION['flash_tipe']);
}

// ── AMBIL DATA ──
$daftarUser = $koneksi->query("SELECT * FROM users ORDER BY created_at DESC");
$totalUser = $koneksi->query("SELECT COUNT(*) c FROM users")->fetch_assoc()['c'];
$totalAdmin = $koneksi->query("SELECT COUNT(*) c FROM users WHERE role='admin'")->fetch_assoc()['c'];
$loginTerakhir = $koneksi->query("SELECT l.*, u.nama_lengkap FROM login_log l LEFT JOIN users u ON l.user_id = u.id ORDER BY l.waktu DESC LIMIT 10");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard Admin - WebGIS Luwu</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
<style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body { font-family:'Segoe UI',Arial,sans-serif; background:#f0f2f5; }
    #navbar {
        height:56px; background:linear-gradient(135deg,#1a3a5c,#2274b8);
        display:flex; align-items:center; justify-content:space-between; padding:0 20px;
        box-shadow:0 2px 8px rgba(0,0,0,.2);
    }
    #navbar .left { display:flex; align-items:center; gap:10px; color:white; font-weight:700; font-size:15px; }
    #navbar .right { display:flex; gap:8px; }
    .nav-btn { background:rgba(255,255,255,.15); color:white; border:1px solid rgba(255,255,255,.3); border-radius:6px; padding:7px 14px; font-size:12.5px; text-decoration:none; display:flex; align-items:center; gap:6px; }
    .nav-btn:hover { background:rgba(255,255,255,.28); }
    .container { max-width:1100px; margin:24px auto; padding:0 20px; }
    .cards { display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:16px; margin-bottom:24px; }
    .card { background:white; border-radius:10px; padding:18px; box-shadow:0 2px 8px rgba(0,0,0,.06); }
    .card .num { font-size:26px; font-weight:700; color:#1a3a5c; }
    .card .lbl { font-size:12.5px; color:#64748b; margin-top:4px; }
    .panel { background:white; border-radius:10px; box-shadow:0 2px 8px rgba(0,0,0,.06); margin-bottom:24px; overflow:hidden; }
    .panel-header { padding:14px 18px; background:#f8fafc; border-bottom:1px solid #e8ecf0; font-weight:700; font-size:14px; color:#1a3a5c; display:flex; align-items:center; gap:8px; justify-content:space-between; }
    .panel-body { padding:18px; }
    table { width:100%; border-collapse:collapse; font-size:13px; }
    th, td { text-align:left; padding:10px 12px; border-bottom:1px solid #eef1f4; }
    th { color:#64748b; font-weight:600; font-size:12px; text-transform:uppercase; }
    .badge { padding:3px 9px; border-radius:20px; font-size:11px; font-weight:600; }
    .badge.admin { background:#fef3c7; color:#92400e; }
    .badge.user { background:#dbeafe; color:#1e40af; }
    .badge.aktif { background:#dcfce7; color:#166534; }
    .badge.nonaktif { background:#fee2e2; color:#991b1b; }
    .action-btn { border:none; padding:5px 9px; border-radius:5px; font-size:11.5px; cursor:pointer; margin-right:4px; text-decoration:none; display:inline-block; }
    .action-btn.reset { background:#fef3c7; color:#92400e; }
    .action-btn.toggle { background:#e0e7ff; color:#3730a3; }
    .action-btn.delete { background:#fee2e2; color:#991b1b; }
    .btn-primary { background:#2274b8; color:white; border:none; padding:10px 18px; border-radius:7px; font-size:13.5px; cursor:pointer; font-weight:600; }
    .btn-primary:hover { background:#1a5e94; }
    .form-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:12px; align-items:end; }
    label { display:block; font-size:12px; font-weight:600; color:#374151; margin-bottom:5px; }
    input, select { width:100%; padding:9px 10px; border:1px solid #d1d5db; border-radius:6px; font-size:13px; }
    .alert { padding:10px 14px; border-radius:7px; font-size:13px; margin-bottom:16px; }
    .alert.success { background:#f0fdf4; color:#15803d; border:1px solid #bbf7d0; }
    .alert.error { background:#fef2f2; color:#b91c1c; border:1px solid #fecaca; }
    .modal-overlay { display:none; position:fixed; inset:0; background:rgba(0,0,0,.5); align-items:center; justify-content:center; z-index:999; }
    .modal-overlay.show { display:flex; }
    .modal-box { background:white; padding:24px; border-radius:10px; width:90%; max-width:340px; }
    .modal-box h3 { margin-bottom:14px; font-size:15px; color:#1a3a5c; }
    .modal-actions { display:flex; gap:8px; margin-top:16px; }
    .modal-actions button, .modal-actions a { flex:1; text-align:center; padding:9px; border-radius:6px; font-size:13px; text-decoration:none; cursor:pointer; border:none; }
</style>
</head>
<body>

<nav id="navbar">
    <div class="left"><i class="fa fa-map-location-dot"></i> Dashboard Admin — WebGIS Luwu</div>
    <div class="right">
        <a href="../index.php" class="nav-btn"><i class="fa fa-map"></i> Lihat Peta</a>
        <a href="kelola_layer.php" class="nav-btn"><i class="fa fa-file-arrow-up"></i> Kelola Layer</a>
        <a href="../logout.php" class="nav-btn"><i class="fa fa-right-from-bracket"></i> Keluar (<?= htmlspecialchars($user['nama_lengkap']) ?>)</a>
    </div>
</nav>

<div class="container">

    <?php if ($pesan): ?>
        <div class="alert <?= $pesanTipe ?>"><?= htmlspecialchars($pesan) ?></div>
    <?php endif; ?>

    <div class="cards">
        <div class="card"><div class="num"><?= $totalUser ?></div><div class="lbl">Total Pengguna</div></div>
        <div class="card"><div class="num"><?= $totalAdmin ?></div><div class="lbl">Akun Admin</div></div>
        <div class="card"><div class="num">22</div><div class="lbl">Kecamatan Terdata</div></div>
        <div class="card"><div class="num">444</div><div class="lbl">Titik Lokasi Pegawai</div></div>
    </div>

    <!-- TAMBAH USER -->
    <div class="panel">
        <div class="panel-header"><i class="fa fa-user-plus"></i> Tambah Pengguna Baru</div>
        <div class="panel-body">
            <form method="POST">
                <input type="hidden" name="aksi" value="tambah">
                <div class="form-grid">
                    <div>
                        <label>Nama Lengkap</label>
                        <input type="text" name="nama_lengkap" required>
                    </div>
                    <div>
                        <label>Username</label>
                        <input type="text" name="username" required>
                    </div>
                    <div>
                        <label>Password</label>
                        <input type="password" name="password" required minlength="6">
                    </div>
                    <div>
                        <label>Role</label>
                        <select name="role">
                            <option value="user">User (lihat saja)</option>
                            <option value="admin">Admin (kelola data)</option>
                        </select>
                    </div>
                    <div>
                        <button type="submit" class="btn-primary" style="width:100%;"><i class="fa fa-plus"></i> Tambah</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- DAFTAR USER -->
    <div class="panel">
        <div class="panel-header"><i class="fa fa-users"></i> Daftar Pengguna</div>
        <div class="panel-body" style="overflow-x:auto;">
            <table>
                <thead>
                    <tr><th>Nama</th><th>Username</th><th>Role</th><th>Status</th><th>Dibuat</th><th>Aksi</th></tr>
                </thead>
                <tbody>
                <?php while ($row = $daftarUser->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['nama_lengkap']) ?></td>
                        <td><?= htmlspecialchars($row['username']) ?></td>
                        <td><span class="badge <?= $row['role'] ?>"><?= $row['role'] ?></span></td>
                        <td><span class="badge <?= $row['status'] ?>"><?= $row['status'] ?></span></td>
                        <td><?= date('d M Y', strtotime($row['created_at'])) ?></td>
                        <td>
                            <button class="action-btn reset" onclick="bukaModalReset(<?= $row['id'] ?>, '<?= htmlspecialchars($row['nama_lengkap'], ENT_QUOTES) ?>')"><i class="fa fa-key"></i> Reset</button>
                            <?php if ((int)$row['id'] !== (int)$user['id']): ?>
                                <a href="?toggle_status=<?= $row['id'] ?>" class="action-btn toggle"><i class="fa fa-toggle-on"></i> Toggle</a>
                                <a href="#" onclick="bukaModalHapus(<?= $row['id'] ?>, '<?= htmlspecialchars($row['nama_lengkap'], ENT_QUOTES) ?>'); return false;" class="action-btn delete"><i class="fa fa-trash"></i> Hapus</a>
                            <?php else: ?>
                                <span style="font-size:11px;color:#94a3b8;">(akun Anda)</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- LOG LOGIN -->
    <div class="panel">
        <div class="panel-header"><i class="fa fa-clock-rotate-left"></i> Aktivitas Login Terakhir</div>
        <div class="panel-body" style="overflow-x:auto;">
            <table>
                <thead><tr><th>Nama</th><th>Username</th><th>Status</th><th>IP</th><th>Waktu</th></tr></thead>
                <tbody>
                <?php while ($log = $loginTerakhir->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($log['nama_lengkap'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($log['username']) ?></td>
                        <td><span class="badge <?= $log['status']==='sukses'?'aktif':'nonaktif' ?>"><?= $log['status'] ?></span></td>
                        <td style="font-family:monospace;"><?= htmlspecialchars($log['ip_address']) ?></td>
                        <td><?= date('d M Y H:i', strtotime($log['waktu'])) ?></td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<!-- MODAL RESET PASSWORD -->
<div class="modal-overlay" id="modalReset">
    <div class="modal-box">
        <h3><i class="fa fa-key"></i> Reset Password</h3>
        <form method="POST">
            <input type="hidden" name="aksi" value="reset_password">
            <input type="hidden" name="user_id" id="resetUserId">
            <p style="font-size:13px;color:#64748b;margin-bottom:10px;">Untuk: <b id="resetUserNama"></b></p>
            <label>Password Baru</label>
            <input type="password" name="password_baru" minlength="6" required>
            <div class="modal-actions">
                <a href="#" onclick="tutupModal('modalReset'); return false;" style="background:#f1f5f9;color:#374151;">Batal</a>
                <button type="submit" style="background:#2274b8;color:white;">Simpan</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL HAPUS -->
<div class="modal-overlay" id="modalHapus">
    <div class="modal-box">
        <h3><i class="fa fa-triangle-exclamation" style="color:#dc2626;"></i> Hapus Pengguna?</h3>
        <p style="font-size:13px;color:#64748b;">Yakin ingin menghapus <b id="hapusUserNama"></b>? Tindakan ini tidak dapat dibatalkan.</p>
        <div class="modal-actions">
            <a href="#" onclick="tutupModal('modalHapus'); return false;" style="background:#f1f5f9;color:#374151;">Batal</a>
            <a id="linkHapus" href="#" style="background:#dc2626;color:white;">Hapus</a>
        </div>
    </div>
</div>

<script>
function bukaModalReset(id, nama) {
    document.getElementById('resetUserId').value = id;
    document.getElementById('resetUserNama').textContent = nama;
    document.getElementById('modalReset').classList.add('show');
}
function bukaModalHapus(id, nama) {
    document.getElementById('hapusUserNama').textContent = nama;
    document.getElementById('linkHapus').href = '?hapus=' + id;
    document.getElementById('modalHapus').classList.add('show');
}
function tutupModal(id) { document.getElementById(id).classList.remove('show'); }
</script>
</body>
</html>
