<?php
require_once 'auth.php';

// Mode tamu: boleh lihat tanpa login (read-only), tapi kalau bukan tamu, wajib login
$isGuest = isset($_GET['guest']) && !isLoggedIn();
if (!$isGuest) {
    requireLogin();
}

$user = currentUser(); // null kalau mode tamu
$isAdmin = $user && $user['role'] === 'admin';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WebGIS Kabupaten Luwu</title>

    <!-- LEAFLET -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
    <!-- MINIMAP -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/leaflet-minimap@3.6.1/dist/Control.MiniMap.min.css">
    <!-- SEARCH -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet-search@3.0.9/dist/leaflet-search.min.css"/>
    <!-- DRAW -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet.draw/1.0.4/leaflet.draw.css"/>
    <!-- MEASURE -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/leaflet-measure/dist/leaflet-measure.css"/>
    <!-- FONT AWESOME -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Arial, sans-serif; background: #f0f2f5; overflow: hidden; }

        /* ── NAVBAR ── */
        #navbar {
            position: fixed; top: 0; left: 0; right: 0; height: 52px;
            background: linear-gradient(135deg, #1a3a5c 0%, #2274b8 100%);
            display: flex; align-items: center; justify-content: space-between;
            padding: 0 16px; z-index: 2000; box-shadow: 0 2px 8px rgba(0,0,0,0.3);
        }
        #navbar .nav-left { display: flex; align-items: center; gap: 12px; }
        #navbar .nav-logo {
            width: 36px; height: 36px; border-radius: 50%;
            background: white; display: flex; align-items: center; justify-content: center;
        }
        #navbar .nav-logo i { color: #2274b8; font-size: 18px; }
        #navbar .nav-title { color: white; font-size: 15px; font-weight: 700; line-height: 1.2; }
        #navbar .nav-title span { display: block; font-size: 11px; font-weight: 400; opacity: 0.85; }
        #navbar .nav-right { display: flex; align-items: center; gap: 8px; }
        .nav-btn {
            background: rgba(255,255,255,0.15); color: white; border: 1px solid rgba(255,255,255,0.3);
            border-radius: 6px; padding: 5px 12px; cursor: pointer; font-size: 12px;
            display: flex; align-items: center; gap: 6px; transition: background 0.2s;
        }
        .nav-btn:hover { background: rgba(255,255,255,0.28); }
        .nav-btn.active { background: rgba(255,255,255,0.35); }

        /* ── LAYOUT ── */
        #app { position: fixed; top: 52px; left: 0; right: 0; bottom: 0; display: flex; }

        /* ── SIDEBAR ── */
        #sidebar {
            width: 280px; min-width: 280px; background: #fff;
            display: flex; flex-direction: column;
            box-shadow: 2px 0 8px rgba(0,0,0,0.12); z-index: 1000;
            transition: margin-left 0.3s ease;
        }
        #sidebar.collapsed { margin-left: -280px; }

        .sidebar-header {
            background: linear-gradient(135deg, #1a3a5c, #2274b8);
            color: white; padding: 14px 16px; font-weight: 700; font-size: 13px;
            display: flex; align-items: center; gap: 8px;
        }
        .sidebar-section { border-bottom: 1px solid #e8ecf0; }
        .sidebar-section-title {
            padding: 10px 16px; font-size: 11px; font-weight: 700;
            color: #64748b; text-transform: uppercase; letter-spacing: 0.6px;
            background: #f8fafc; display: flex; align-items: center; gap: 6px;
            cursor: pointer; user-select: none;
        }
        .sidebar-section-title i.arrow { margin-left: auto; transition: transform 0.2s; }
        .sidebar-section-title.open i.arrow { transform: rotate(180deg); }
        .sidebar-section-body { padding: 10px 14px; }

        /* Layer toggles */
        .layer-item {
            display: flex; align-items: center; gap: 10px;
            padding: 7px 8px; border-radius: 6px; cursor: pointer;
            transition: background 0.15s; margin-bottom: 2px; font-size: 13px;
        }
        .layer-item:hover { background: #f1f5f9; }
        .layer-item input[type=checkbox] { width: 15px; height: 15px; cursor: pointer; accent-color: #2274b8; }
        .layer-color-box { width: 14px; height: 14px; border-radius: 3px; border: 1px solid rgba(0,0,0,0.15); flex-shrink: 0; }

        /* Basemap radios */
        .basemap-item {
            display: flex; align-items: center; gap: 10px;
            padding: 7px 8px; border-radius: 6px; cursor: pointer;
            transition: background 0.15s; margin-bottom: 2px; font-size: 13px;
        }
        .basemap-item:hover { background: #f1f5f9; }
        .basemap-item input[type=radio] { accent-color: #2274b8; cursor: pointer; }

        /* Legenda */
        #legend-list { max-height: 300px; overflow-y: auto; }
        .legend-item {
            display: flex; align-items: center; gap: 8px;
            padding: 4px 0; font-size: 12px; color: #374151;
        }
        .legend-sq { width: 14px; height: 14px; border-radius: 3px; border: 1px solid rgba(0,0,0,0.15); flex-shrink: 0; }

        /* Info panel */
        #info-panel {
            margin: 10px 14px; padding: 10px 12px; border-radius: 8px;
            background: #f0f7ff; border: 1px solid #bfdbfe; font-size: 12px;
            color: #1e3a5f; line-height: 1.7; min-height: 64px;
        }
        #info-panel b { display: block; margin-bottom: 4px; color: #1a3a5c; }

        /* Sidebar toggle button */
        #sidebar-toggle {
            position: absolute; top: 50%; left: 280px; transform: translateY(-50%);
            width: 20px; height: 48px; background: #2274b8; color: white;
            border: none; border-radius: 0 6px 6px 0; cursor: pointer; z-index: 1001;
            display: flex; align-items: center; justify-content: center;
            transition: left 0.3s ease; box-shadow: 2px 0 6px rgba(0,0,0,0.2);
        }
        #sidebar-toggle.collapsed { left: 0; }
        #sidebar-toggle i { font-size: 10px; transition: transform 0.3s; }
        #sidebar-toggle.collapsed i { transform: rotate(180deg); }

        /* ── MAP ── */
        #map-container { flex: 1; position: relative; }
        #map { width: 100%; height: 100%; }

        /* Koordinat bar */
        #coord-bar {
            position: absolute; bottom: 0; left: 0; right: 0; height: 22px;
            background: rgba(26,58,92,0.88); color: #e2e8f0;
            display: flex; align-items: center; padding: 0 12px; gap: 20px;
            font-size: 11px; z-index: 900; font-family: monospace;
        }

        /* Label style */
        .styleLabelKecamatan {
            background: transparent; border: 0;
            font-size: 10pt; color: white; font-weight: 700;
            text-shadow: 1px 1px 3px black, -1px -1px 3px black;
            pointer-events: none;
        }

        /* Popup */
        .leaflet-popup-content-wrapper {
            padding: 0 !important; border-radius: 8px !important; overflow: hidden;
            box-shadow: 0 6px 20px rgba(0,0,0,0.22) !important;
        }
        .leaflet-popup-content { margin: 0 !important; }

        /* Legend scroll */
        #legend-list::-webkit-scrollbar { width: 4px; }
        #legend-list::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 2px; }

        /* Modal About */
        #modal-overlay {
            display: none; position: fixed; inset: 0;
            background: rgba(0,0,0,0.5); z-index: 3000;
            align-items: center; justify-content: center;
        }
        #modal-overlay.show { display: flex; }
        #modal-box {
            background: white; border-radius: 12px; padding: 28px 32px;
            max-width: 420px; width: 90%; box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        #modal-box h2 { color: #1a3a5c; margin-bottom: 10px; font-size: 17px; }
        #modal-box p { font-size: 13px; color: #475569; line-height: 1.7; margin-bottom: 8px; }
        #modal-box .close-btn {
            margin-top: 16px; background: #2274b8; color: white;
            border: none; border-radius: 6px; padding: 8px 20px;
            cursor: pointer; font-size: 13px; float: right;
        }

        .legend { display:none; } /* hide default leaflet legend */

        hr { border: none; border-top: 1px solid #e2e8f0; margin: 6px 0; }
    </style>
</head>
<body>

<!-- NAVBAR -->
<nav id="navbar">
    <div class="nav-left">
        <div class="nav-logo"><i class="fa fa-map-location-dot"></i></div>
        <div class="nav-title">
            WebGIS Kabupaten Luwu
            <span>Sulawesi Selatan — Sistem Informasi Geografis</span>
        </div>
    </div>
    <div class="nav-right">
        <button class="nav-btn" id="btn-home" title="Reset View"><i class="fa fa-house"></i> Beranda</button>
        <button class="nav-btn" id="btn-fullext" title="Full Extent"><i class="fa fa-expand"></i> Full Extent</button>
        <button class="nav-btn" id="btn-about"><i class="fa fa-circle-info"></i> Tentang</button>
        <?php if ($isAdmin): ?>
            <a href="admin/dashboard.php" class="nav-btn" style="text-decoration:none;"><i class="fa fa-user-shield"></i> Dashboard Admin</a>
        <?php endif; ?>
        <?php if ($user): ?>
            <span class="nav-btn" style="cursor:default;background:rgba(255,255,255,0.08);">
                <i class="fa fa-user"></i> <?= htmlspecialchars($user['nama_lengkap']) ?>
                <span style="opacity:.7;font-size:10px;">(<?= htmlspecialchars($user['role']) ?>)</span>
            </span>
            <a href="logout.php" class="nav-btn" style="text-decoration:none;"><i class="fa fa-right-from-bracket"></i> Keluar</a>
        <?php else: ?>
            <span class="nav-btn" style="cursor:default;background:rgba(255,255,255,0.08);"><i class="fa fa-eye"></i> Mode Tamu</span>
            <a href="login.php" class="nav-btn" style="text-decoration:none;"><i class="fa fa-right-to-bracket"></i> Login</a>
        <?php endif; ?>
    </div>
</nav>

<!-- APP -->
<div id="app">

    <!-- SIDEBAR TOGGLE -->
    <button id="sidebar-toggle"><i class="fa fa-chevron-left"></i></button>

    <!-- SIDEBAR -->
    <div id="sidebar">
        <div class="sidebar-header">
            <i class="fa fa-layer-group"></i> Panel Kontrol
        </div>

        <!-- INFO KLIK -->
        <div class="sidebar-section">
            <div class="sidebar-section-title open" onclick="toggleSection(this)">
                <i class="fa fa-circle-info"></i> Info Wilayah
                <i class="fa fa-chevron-down arrow"></i>
            </div>
            <div class="sidebar-section-body">
                <div id="info-panel">
                    <b>ℹ️ Informasi Wilayah</b>
                    Klik pada wilayah kecamatan untuk melihat detail informasi.
                </div>
            </div>
        </div>

        <!-- OVERLAY LAYERS -->
        <div class="sidebar-section">
            <div class="sidebar-section-title open" onclick="toggleSection(this)">
                <i class="fa fa-layer-group"></i> Layer Data
                <i class="fa fa-chevron-down arrow"></i>
            </div>
            <div class="sidebar-section-body">
                <label class="layer-item">
                    <input type="checkbox" id="chk-kecamatan" checked>
                    <div class="layer-color-box" style="background:linear-gradient(135deg,#2274b8,#f7265a);"></div>
                    <span>Kecamatan Luwu</span>
                </label>
                <label class="layer-item">
                    <input type="checkbox" id="chk-pegawai" checked>
                    <img src="libs/pemerintahan/pin_merah.png" style="width:12px;height:16px;object-fit:contain;">
                    <span>Lokasi Pegawai</span>
                </label>
            </div>
        </div>

        <!-- BASEMAP -->
        <div class="sidebar-section">
            <div class="sidebar-section-title open" onclick="toggleSection(this)">
                <i class="fa fa-map"></i> Peta Dasar
                <i class="fa fa-chevron-down arrow"></i>
            </div>
            <div class="sidebar-section-body">
                <label class="basemap-item">
                    <input type="radio" name="basemap" value="osm" checked> OpenStreetMap
                </label>
                <label class="basemap-item">
                    <input type="radio" name="basemap" value="satellite"> Satelit (Google)
                </label>
                <label class="basemap-item">
                    <input type="radio" name="basemap" value="terrain"> Topografi (Google)
                </label>
            </div>
        </div>

        <!-- LEGENDA -->
        <div class="sidebar-section">
            <div class="sidebar-section-title open" onclick="toggleSection(this)">
                <i class="fa fa-list"></i> Legenda
                <i class="fa fa-chevron-down arrow"></i>
            </div>
            <div class="sidebar-section-body">
                <div id="legend-list"></div>
                <hr>
                <div class="legend-item">
                    <img src="libs/pemerintahan/pin_merah.png" style="width:12px;height:16px;object-fit:contain;">
                    <span>Lokasi Pegawai</span>
                </div>
            </div>
        </div>

        <!-- STATISTIK -->
        <div class="sidebar-section">
            <div class="sidebar-section-title open" onclick="toggleSection(this)">
                <i class="fa fa-chart-bar"></i> Statistik
                <i class="fa fa-chevron-down arrow"></i>
            </div>
            <div class="sidebar-section-body" style="font-size:12px;color:#374151;line-height:2;">
                <div><i class="fa fa-map-pin" style="color:#2274b8;width:16px;"></i> Jumlah Kecamatan: <b>22</b></div>
                <div><i class="fa fa-location-dot" style="color:#e62156;width:16px;"></i> Lokasi Pegawai: <b>444</b></div>
                <div><i class="fa fa-location-crosshairs" style="color:#159c10;width:16px;"></i> Kabupaten: <b>Luwu</b></div>
                <div><i class="fa fa-globe" style="color:#ff7f00;width:16px;"></i> Provinsi: <b>Sulawesi Selatan</b></div>
            </div>
        </div>

        <?php if ($isAdmin): ?>
        <!-- PANEL ADMIN -->
        <div class="sidebar-section">
            <div class="sidebar-section-title open" onclick="toggleSection(this)">
                <i class="fa fa-user-shield"></i> Panel Admin
                <i class="fa fa-chevron-down arrow"></i>
            </div>
            <div class="sidebar-section-body" style="font-size:12.5px;">
                <p style="color:#64748b;margin-bottom:10px;line-height:1.6;">Kelola akun pengguna dan data layer peta.</p>
                <a href="admin/dashboard.php" style="display:block;text-decoration:none;background:#2274b8;color:white;text-align:center;padding:8px;border-radius:6px;margin-bottom:6px;">
                    <i class="fa fa-users"></i> Kelola User
                </a>
                <a href="admin/kelola_layer.php" style="display:block;text-decoration:none;background:#159c10;color:white;text-align:center;padding:8px;border-radius:6px;">
                    <i class="fa fa-file-arrow-up"></i> Kelola Data Layer
                </a>
            </div>
        </div>
        <?php endif; ?>

    </div><!-- /sidebar -->

    <!-- MAP -->
    <div id="map-container">
        <div id="map"></div>
        <div id="coord-bar">
            <span><i class="fa fa-location-crosshairs"></i> Lat: <span id="coord-lat">-</span></span>
            <span>Lng: <span id="coord-lng">-</span></span>
            <span><i class="fa fa-magnifying-glass"></i> Zoom: <span id="coord-zoom">10</span></span>
        </div>
    </div>

</div><!-- /app -->

<!-- MODAL ABOUT -->
<div id="modal-overlay">
    <div id="modal-box">
        <h2><i class="fa fa-map-location-dot" style="color:#2274b8;"></i> WebGIS Kabupaten Luwu</h2>
        <p>Sistem Informasi Geografis berbasis web untuk visualisasi data spasial Kabupaten Luwu, Sulawesi Selatan.</p>
        <p><b>Data yang ditampilkan:</b></p>
        <p>• Batas wilayah 22 Kecamatan<br>• 444 Titik Lokasi Pegawai</p>
        <p><b>Teknologi:</b> Leaflet.js · OpenStreetMap · GeoJSON</p>
        <button class="close-btn" onclick="document.getElementById('modal-overlay').classList.remove('show')">Tutup</button>
        <div style="clear:both;"></div>
    </div>
</div>

<!-- LEAFLET JS -->
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script src="https://cdn.jsdelivr.net/npm/leaflet-minimap@3.6.1/dist/Control.MiniMap.min.js"></script>
<script src="https://unpkg.com/leaflet-search@3.0.9/dist/leaflet-search.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet.draw/1.0.4/leaflet.draw.js"></script>
<script src="https://cdn.jsdelivr.net/npm/leaflet-measure/dist/leaflet-measure.min.js"></script>
<script src="https://unpkg.com/leaflet.browser.print/dist/leaflet.browser.print.min.js"></script>

<!-- DATA -->
<script src="js/luwu.js"></script>
<script src="js/pegawai.js"></script>

<script>
// ── SIDEBAR TOGGLE ──
function toggleSection(el) {
    el.classList.toggle('open');
    var body = el.nextElementSibling;
    body.style.display = el.classList.contains('open') ? '' : 'none';
}
var sidebarToggleBtn = document.getElementById('sidebar-toggle');
var sidebar = document.getElementById('sidebar');
sidebarToggleBtn.addEventListener('click', function() {
    sidebar.classList.toggle('collapsed');
    sidebarToggleBtn.classList.toggle('collapsed');
    setTimeout(function(){ map.invalidateSize(); }, 320);
});

// ── MAP ──
var map = L.map('map', { zoomControl: false }).setView([-3.165156979860683, 120.15347200373009], 10);
L.control.zoom({ position: 'topright' }).addTo(map);

// ── BASEMAPS ──
var osm = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19, attribution: '&copy; OpenStreetMap'
});
var imagery = L.tileLayer('https://{s}.google.com/vt/lyrs=s&x={x}&y={y}&z={z}', {
    maxZoom: 20, subdomains: ['mt0','mt1','mt2','mt3']
});
var terrain = L.tileLayer('https://{s}.google.com/vt/lyrs=p&x={x}&y={y}&z={z}', {
    maxZoom: 20, subdomains: ['mt0','mt1','mt2','mt3']
});
osm.addTo(map);

document.querySelectorAll('input[name=basemap]').forEach(function(radio) {
    radio.addEventListener('change', function() {
        [osm, imagery, terrain].forEach(function(l){ map.removeLayer(l); });
        if (this.value === 'osm')       osm.addTo(map);
        if (this.value === 'satellite') imagery.addTo(map);
        if (this.value === 'terrain')   terrain.addTo(map);
    });
});

// ── WARNA ──
function getColor(nama) {
    var w = {
        "Bajo":"#f7265a","Bajo Barat":"#2274b8","Basse Sangtempe":"#159c10",
        "Basse Sangtempe Utara":"#ff7f00","Belopa":"#80a22b","Belopa Utara":"#29b8a2",
        "Bua":"#4c2ba5","Bua Ponrang":"#ecc519","Kamanre":"#e62156","Lamasi":"#a53084",
        "Lamasi Timur":"#a721d7","Larompong":"#d397df","Larompong Selatan":"#71e45c",
        "Latimojong":"#ff4500","Ponrang":"#00ced1","Ponrang Selatan":"#8b0000",
        "Suli":"#006400","Suli Barat":"#4169e1","Walenrang":"#ff69b4",
        "Walenrang Barat":"#daa520","Walenrang Timur":"#20b2aa","Walenrang Utara":"#9932cc"
    };
    return w[nama] || "#bc2121";
}

// ── KECAMATAN LAYER ──
function styleKec(feature) {
    return { fillColor: getColor(feature.properties.WADMKC), weight: 2, opacity: 1, color: 'white', dashArray: '3', fillOpacity: 0.7 };
}
function highlight(e) {
    e.target.setStyle({ weight: 5, color: '#333', dashArray: '', fillOpacity: 0.8 });
    e.target.bringToFront();
}
function resetHL(e) { luwulayer.resetStyle(e.target); }

function onEachKec(feature, layer) {
    layer.on({
        mouseover: highlight,
        mouseout: resetHL,
        click: function(e) {
            var p = feature.properties;
            var nama = p.WADMKC || '-';
            var luas = p.Shape_Area ? (p.Shape_Area * 12321000000).toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g,'.') + ' m²' : '-';
            // Update sidebar info
            document.getElementById('info-panel').innerHTML =
                '<b style="color:' + getColor(nama) + '">🗺️ Kec. ' + nama + '</b>' +
                '<span>Kabupaten: <b>Luwu</b></span><br>' +
                '<span>Provinsi: <b>Sulawesi Selatan</b></span><br>' +
                '<span>Luas: <b>' + luas + '</b></span>';
            // Popup
            var html = '<div style="font-family:Arial,sans-serif;min-width:200px;">' +
                '<div style="background:' + getColor(nama) + ';color:white;padding:7px 12px;border-radius:4px 4px 0 0;font-weight:bold;font-size:13px;">🗺️ Kecamatan ' + nama + '</div>' +
                '<div style="padding:9px 12px;font-size:12px;line-height:1.9;">' +
                '<b>Kabupaten:</b> Luwu<br><b>Provinsi:</b> Sulawesi Selatan<br><b>Luas:</b> ' + luas + '</div></div>';
            layer.bindPopup(html, { maxWidth: 280 }).openPopup(e.latlng);
        }
    });
    layer.bindTooltip('Kec. ' + (feature.properties.WADMKC || ''), {
        direction: 'center', permanent: true, className: 'styleLabelKecamatan'
    });
}

var luwulayer = L.geoJSON(luwudata, { style: styleKec, onEachFeature: onEachKec }).addTo(map);

// Label zoom
function updateLabels() {
    luwulayer.eachLayer(function(l){ map.getZoom() >= 10 ? l.openTooltip() : l.closeTooltip(); });
}
updateLabels();
map.on('zoomend', updateLabels);

// ── PEGAWAI LAYER ──
var pinIcon = L.icon({
    iconUrl: 'libs/pemerintahan/pin_merah.png',
    iconSize: [28,35], iconAnchor: [14,35], popupAnchor: [0,-35]
});
var pegawailayer = L.geoJSON(pegawaidata, {
    pointToLayer: function(f, ll) { return L.marker(ll, { icon: pinIcon }); },
    onEachFeature: function(f, layer) {
        var titik = f.properties.Titik_pega || 'Lokasi Pegawai';
        layer.bindPopup(
            '<div style="font-family:Arial,sans-serif;min-width:170px;">' +
            '<div style="background:#e62156;color:white;padding:7px 12px;border-radius:4px 4px 0 0;font-weight:bold;font-size:13px;">📍 Lokasi Pegawai</div>' +
            '<div style="padding:9px 12px;font-size:12px;line-height:1.9;"><b>Titik:</b> ' + titik + '<br><b>ID:</b> ' + (f.properties.Id ?? '-') + '</div></div>',
            { maxWidth: 240 }
        );
    }
}).addTo(map);

// ── LAYER TOGGLES (sidebar checkbox) ──
document.getElementById('chk-kecamatan').addEventListener('change', function() {
    this.checked ? luwulayer.addTo(map) : map.removeLayer(luwulayer);
});
document.getElementById('chk-pegawai').addEventListener('change', function() {
    this.checked ? pegawailayer.addTo(map) : map.removeLayer(pegawailayer);
});

// ── BUILD LEGENDA SIDEBAR ──
var kecList = ["Bajo","Bajo Barat","Basse Sangtempe","Basse Sangtempe Utara","Belopa","Belopa Utara",
    "Bua","Bua Ponrang","Kamanre","Lamasi","Lamasi Timur","Larompong","Larompong Selatan","Latimojong",
    "Ponrang","Ponrang Selatan","Suli","Suli Barat","Walenrang","Walenrang Barat","Walenrang Timur","Walenrang Utara"];
var legHtml = '';
kecList.forEach(function(n){
    legHtml += '<div class="legend-item"><div class="legend-sq" style="background:' + getColor(n) + ';"></div><span>' + n + '</span></div>';
});
document.getElementById('legend-list').innerHTML = legHtml;

// ── TOOLS ──
// MiniMap
new L.Control.MiniMap(L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{minZoom:0,maxZoom:13}),{
    toggleDisplay:true, minimized:false, position:'bottomleft'
}).addTo(map);

// Scale
L.control.scale({ position:'bottomleft', metric:true, imperial:false }).addTo(map);

// Search
map.addControl(new L.Control.Search({
    layer: luwulayer, propertyName: 'WADMKC', marker: false,
    moveToLocation: function(ll, t, m){ m.setView(ll, 12); }
}));

// Measure
L.control.measure({ position:'topright', primaryLengthUnit:'kilometers', secondaryLengthUnit:'meters', primaryAreaUnit:'hectares' }).addTo(map);

// Draw
var drawnItems = new L.FeatureGroup();
map.addLayer(drawnItems);
map.addControl(new L.Control.Draw({
    edit:{ featureGroup: drawnItems },
    draw:{ polygon:true, polyline:true, rectangle:true, circle:true, marker:true, circlemarker:false }
}));
map.on(L.Draw.Event.CREATED, function(e){ drawnItems.addLayer(e.layer); });

// Print
L.control.browserPrint({ position:'topright' }).addTo(map);

// ── KOORDINAT BAR ──
map.on('mousemove', function(e) {
    document.getElementById('coord-lat').textContent = e.latlng.lat.toFixed(6);
    document.getElementById('coord-lng').textContent = e.latlng.lng.toFixed(6);
});
map.on('zoomend', function(){ document.getElementById('coord-zoom').textContent = map.getZoom(); });

// ── NAVBAR BUTTONS ──
document.getElementById('btn-home').addEventListener('click', function(){
    map.setView([-3.165156979860683, 120.15347200373009], 10);
});
document.getElementById('btn-fullext').addEventListener('click', function(){
    map.fitBounds(luwulayer.getBounds(), { padding: [20,20] });
});
document.getElementById('btn-about').addEventListener('click', function(){
    document.getElementById('modal-overlay').classList.add('show');
});
document.getElementById('modal-overlay').addEventListener('click', function(e){
    if (e.target === this) this.classList.remove('show');
});
</script>
</body>
</html>
