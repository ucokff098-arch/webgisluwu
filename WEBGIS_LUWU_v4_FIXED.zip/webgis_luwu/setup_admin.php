<?php
/**
 * ============================================================
 * SETUP AKUN ADMIN PERTAMA — JALANKAN SEKALI SAJA
 * ============================================================
 * Cara pakai:
 * 1. Upload file ini ke server bersama config.php yang sudah diisi benar
 * 2. Buka di browser: https://domainkamu.com/setup_admin.php
 * 3. Isi form, klik "Buat Admin"
 * 4. SETELAH BERHASIL, HAPUS FILE INI DARI SERVER (lewat File Manager Infinityfree)
 *    Jika file ini masih ada, siapa saja yang tahu URL-nya bisa membuat akun admin baru!
 * ============================================================
 */
require_once 'config.php';

$pesan = '';
$sukses = false;

// Cek apakah sudah ada admin (supaya tidak disalahgunakan berkali-kali sembarangan)
$cekAdmin = $koneksi->query("SELECT COUNT(*) as total FROM users WHERE role='admin'");
$jumlahAdmin = (int)$cekAdmin->fetch_assoc()['total'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $jumlahAdmin > 0) {
    // Kunci keras: kalau sudah ada admin, form ini TIDAK BOLEH dipakai lagi.
    // Ini mencegah orang lain membuat akun admin baru kalau file ini lupa dihapus.
    $pesan = 'Akun admin sudah ada. Form ini terkunci demi keamanan. Gunakan menu "Tambah Pengguna" di Dashboard Admin, lalu hapus file setup_admin.php dari server.';
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $nama     = trim($_POST['nama_lengkap'] ?? '');

    if ($username === '' || $password === '' || $nama === '') {
        $pesan = 'Semua field wajib diisi.';
    } elseif (strlen($password) < 6) {
        $pesan = 'Password minimal 6 karakter.';
    } else {
        // Cek username sudah dipakai atau belum
        $stmt = $koneksi->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->bind_param('s', $username);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            $pesan = 'Username sudah dipakai, pilih username lain.';
        } else {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt2 = $koneksi->prepare("INSERT INTO users (username, password, nama_lengkap, role, status) VALUES (?, ?, ?, 'admin', 'aktif')");
            $stmt2->bind_param('sss', $username, $hash, $nama);
            if ($stmt2->execute()) {
                $sukses = true;
                $pesan = 'Akun admin berhasil dibuat! Silakan login, lalu HAPUS file setup_admin.php ini dari server.';
            } else {
                $pesan = 'Gagal membuat akun. Coba lagi.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Setup Admin - WebGIS Luwu</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
    * { box-sizing: border-box; }
    body { font-family: 'Segoe UI', Arial, sans-serif; background: #f0f2f5; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; }
    .box { background: white; padding: 32px; border-radius: 12px; box-shadow: 0 10px 40px rgba(0,0,0,0.1); width: 100%; max-width: 380px; }
    h2 { color: #1a3a5c; margin: 0 0 6px; font-size: 19px; }
    p.sub { color: #64748b; font-size: 13px; margin: 0 0 20px; }
    label { display: block; font-size: 13px; font-weight: 600; color: #374151; margin: 14px 0 5px; }
    input { width: 100%; padding: 10px 12px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 14px; }
    button { width: 100%; margin-top: 20px; padding: 11px; background: #2274b8; color: white; border: none; border-radius: 6px; font-size: 14px; font-weight: 600; cursor: pointer; }
    button:hover { background: #1a5e94; }
    .alert { padding: 10px 12px; border-radius: 6px; font-size: 13px; margin-bottom: 14px; }
    .alert.error { background: #fef2f2; color: #b91c1c; border: 1px solid #fecaca; }
    .alert.success { background: #f0fdf4; color: #15803d; border: 1px solid #bbf7d0; }
    .warn { background: #fffbeb; color: #92400e; border: 1px solid #fde68a; padding: 10px 12px; border-radius: 6px; font-size: 12px; margin-top: 16px; line-height: 1.6; }
</style>
</head>
<body>
<div class="box">
    <h2>🔧 Setup Admin Pertama</h2>
    <p class="sub">WebGIS Kabupaten Luwu</p>

    <?php if ($jumlahAdmin > 0 && !$sukses): ?>
        <div class="alert error">
            🔒 Sudah ada <?= (int)$jumlahAdmin ?> akun admin terdaftar. Form ini terkunci otomatis demi keamanan — gunakan menu "Tambah Pengguna" di Dashboard Admin untuk menambah admin lain. Segera hapus file <code>setup_admin.php</code> ini dari server.
        </div>
    <?php endif; ?>

    <?php if ($pesan && $jumlahAdmin === 0): ?>
        <div class="alert <?= $sukses ? 'success' : 'error' ?>"><?= htmlspecialchars($pesan) ?></div>
    <?php endif; ?>

    <?php if ($jumlahAdmin === 0 && !$sukses): ?>
    <form method="POST">
        <label>Nama Lengkap</label>
        <input type="text" name="nama_lengkap" required value="<?= htmlspecialchars($_POST['nama_lengkap'] ?? '') ?>">

        <label>Username</label>
        <input type="text" name="username" required value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">

        <label>Password (min. 6 karakter)</label>
        <input type="password" name="password" required minlength="6">

        <button type="submit">Buat Akun Admin</button>
    </form>
    <?php elseif ($sukses): ?>
        <a href="login.php" style="display:block;text-align:center;margin-top:8px;color:#2274b8;font-size:13px;font-weight:600;">→ Lanjut ke halaman Login</a>
    <?php endif; ?>

    <div class="warn">
        ⚠️ <b>Penting:</b> setelah akun admin berhasil dibuat, segera hapus file <code>setup_admin.php</code> dari server lewat File Manager Infinityfree. Jika dibiarkan, orang lain yang menemukan URL ini bisa membuat akun admin sendiri.
    </div>
</div>
</body>
</html>
