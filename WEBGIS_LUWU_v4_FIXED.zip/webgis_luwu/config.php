<?php
/**
 * ============================================================
 * KONFIGURASI DATABASE — INFINITYFREE
 * ============================================================
 * INI SATU-SATUNYA FILE YANG WAJIB KAMU EDIT SAAT UPLOAD KE INFINITYFREE.
 * Cukup ganti 4 baris di bagian "GANTI 4 BARIS" di bawah. JANGAN ubah
 * bagian setelahnya kecuali kamu tahu apa yang kamu lakukan.
 *
 * ── CARA DAPAT 4 NILAI DI BAWAH (PENTING, BACA DULU) ──
 *
 * 1. Login ke Client Area Infinityfree -> menu "Accounts" -> klik akun
 *    hosting kamu -> klik tombol "Control Panel" (ini membuka VistaPanel).
 *
 * 2. Di VistaPanel, cari & klik menu "MySQL Databases".
 *    - Kalau belum ada database: buat dulu (isi nama pendek, mis. "webgis",
 *      lalu klik "Create Database"). Tunggu sampai muncul di "Current Databases".
 *    - Kalau sudah ada: lihat di bagian "Current Databases", catat:
 *        > MySQL Host Name   -> ini untuk DB_HOST
 *        > MySQL DB Name     -> ini untuk DB_NAME
 *        > MySQL User Name   -> ini untuk DB_USER
 *
 *    Catatan format (akun Infinityfree generasi terbaru memakai prefix "if0_"):
 *        DB_HOST biasanya seperti: sql200.infinityfree.com
 *        DB_NAME biasanya seperti: if0_xxxxxxxx_webgis
 *        DB_USER biasanya SAMA dengan DB_NAME (if0_xxxxxxxx_webgis)
 *    (Kalau akun kamu generasi lama, prefix-nya bisa "epiz_" alih-alih "if0_".
 *     Apapun prefix-nya, SELALU copy-paste langsung dari VistaPanel kamu
 *     sendiri — jangan menebak atau mengetik ulang manual, karena salah
 *     satu huruf/angka saja membuat koneksi gagal.)
 *
 * 3. Untuk DB_PASS (password database):
 *    INI SERING SALAH PAHAM -> password database BUKAN password baru yang
 *    kamu buat saat membuat database. Password database = PASSWORD AKUN
 *    HOSTING kamu (yang kamu pakai login ke Client Area / VistaPanel).
 *    Cara lihat: Client Area -> klik akun hosting kamu -> cari bagian
 *    "Account Password" -> klik "Show" -> copy password yang muncul.
 *
 * 4. Tunggu 5-15 menit setelah membuat database baru sebelum mencoba
 *    konek — kadang ada delay propagasi di sisi Infinityfree.
 * ============================================================
 */

// ── GANTI 4 BARIS DI BAWAH INI DENGAN DATA DARI VISTAPANEL KAMU ──
define('DB_HOST', 'sql200.infinityfree.com');       // MySQL Host Name dari VistaPanel
define('DB_NAME', 'if0_xxxxxxxx_webgis');           // MySQL DB Name dari VistaPanel
define('DB_USER', 'if0_xxxxxxxx_webgis');           // MySQL User Name dari VistaPanel (biasanya = DB_NAME)
define('DB_PASS', 'PASSWORD_AKUN_HOSTING_KAMU');    // Password AKUN HOSTING (bukan password baru), lihat poin 3 di atas

// ── MODE DEBUG (ubah sementara jadi true kalau koneksi gagal & ingin lihat detail error) ──
// PENTING: kembalikan ke false lagi sebelum sidang/demo/go-live, supaya detail
// teknis server tidak terlihat oleh pengunjung.
define('DEBUG_MODE', false);

// ══════════════════════════════════════════════════════════
// JANGAN UBAH BAGIAN DI BAWAH INI
// ══════════════════════════════════════════════════════════
error_reporting(E_ALL);
ini_set('display_errors', DEBUG_MODE ? 1 : 0);

mysqli_report(DEBUG_MODE ? MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT : MYSQLI_REPORT_OFF);

try {
    $koneksi = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
} catch (mysqli_sql_exception $e) {
    if (DEBUG_MODE) {
        die('Koneksi database GAGAL (mode debug aktif). Detail teknis: ' . htmlspecialchars($e->getMessage()) .
            '<br><br>Cek kembali 4 nilai DB_HOST / DB_NAME / DB_USER / DB_PASS di config.php. ' .
            'Pastikan kamu copy-paste langsung dari VistaPanel -> MySQL Databases, dan DB_PASS adalah password AKUN HOSTING (bukan password lain).');
    }
    die('Koneksi database gagal. Silakan cek kembali konfigurasi di config.php. (Detail teknis disembunyikan demi keamanan — aktifkan DEBUG_MODE di config.php untuk melihat detail saat troubleshooting)');
}

if ($koneksi->connect_error) {
    if (DEBUG_MODE) {
        die('Koneksi database gagal. Detail: ' . htmlspecialchars($koneksi->connect_error) .
            ' (errno: ' . $koneksi->connect_errno . ')');
    }
    die('Koneksi database gagal. Silakan cek kembali konfigurasi di config.php. (Detail teknis disembunyikan demi keamanan — aktifkan DEBUG_MODE di config.php untuk melihat detail saat troubleshooting)');
}

$koneksi->set_charset('utf8mb4');

// Mulai session di semua halaman yang memanggil file ini
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
