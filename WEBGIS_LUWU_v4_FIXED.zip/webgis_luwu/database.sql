-- ============================================================
-- DATABASE: WebGIS Kabupaten Luwu - Sistem Login & Role
-- ============================================================
-- CARA PAKAI:
-- 1. Buka phpMyAdmin di VistaPanel Infinityfree (Control Panel akun hosting kamu)
-- 2. Pilih database kamu (atau buat dulu via menu "MySQL Databases")
-- 3. Klik tab "Import" -> upload file ini, atau klik tab "SQL" -> copy-paste isi file ini -> Go
-- ============================================================

-- Tabel user (admin & user biasa)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,        -- akan disimpan dalam bentuk hash (bcrypt), bukan plain text
    nama_lengkap VARCHAR(100) NOT NULL,
    role ENUM('admin','user') NOT NULL DEFAULT 'user',
    status ENUM('aktif','nonaktif') NOT NULL DEFAULT 'aktif',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabel log aktivitas login
CREATE TABLE IF NOT EXISTS login_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    username VARCHAR(50) NOT NULL,
    status ENUM('sukses','gagal') NOT NULL,
    ip_address VARCHAR(45) DEFAULT NULL,
    waktu TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- AKUN ADMIN PERTAMA
-- ============================================================
-- JANGAN insert user manual lewat SQL (karena password butuh hash bcrypt
-- yang tidak praktis dibuat manual lewat phpMyAdmin).
--
-- Setelah import tabel ini, buka file setup_admin.php sekali lewat
-- browser untuk membuat akun admin pertama dengan password pilihanmu.
-- Setelah berhasil, file setup_admin.php WAJIB dihapus dari server demi keamanan.
