<?php
/**
 * AUTH GUARD
 * Include file ini di paling atas halaman yang ingin diproteksi.
 *
 * Pemakaian:
 *   require_once 'auth.php';                 -> wajib login (role apapun)
 *   require_once 'auth.php'; requireRole('admin'); -> wajib login DAN role admin
 */
require_once __DIR__ . '/config.php';

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function currentUser() {
    if (!isLoggedIn()) return null;
    return [
        'id'           => $_SESSION['user_id'],
        'username'     => $_SESSION['username'],
        'nama_lengkap' => $_SESSION['nama_lengkap'],
        'role'         => $_SESSION['role'],
    ];
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: ' . basePath() . 'login.php');
        exit;
    }
}

function requireRole($role) {
    requireLogin();
    if ($_SESSION['role'] !== $role) {
        header('Location: ' . basePath() . 'index.php');
        exit;
    }
}

// Menentukan prefix path relatif tergantung kedalaman folder (dipakai di admin/ subfolder)
function basePath() {
    return strpos($_SERVER['SCRIPT_NAME'], '/admin/') !== false ? '../' : '';
}
