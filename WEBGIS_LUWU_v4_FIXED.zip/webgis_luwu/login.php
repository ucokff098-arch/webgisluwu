<?php
require_once 'config.php';

// Kalau sudah login, langsung lempar ke peta
if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $error = 'Username dan password wajib diisi.';
    } else {
        $stmt = $koneksi->prepare("SELECT id, username, password, nama_lengkap, role, status FROM users WHERE username = ?");
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        $ip = $_SERVER['REMOTE_ADDR'] ?? '';

        if ($user && password_verify($password, $user['password'])) {
            if ($user['status'] === 'nonaktif') {
                $error = 'Akun ini telah dinonaktifkan. Hubungi administrator.';
                catatLog($koneksi, $user['id'], $username, 'gagal', $ip);
            } else {
                // Login sukses
                session_regenerate_id(true);
                $_SESSION['user_id']      = $user['id'];
                $_SESSION['username']     = $user['username'];
                $_SESSION['nama_lengkap'] = $user['nama_lengkap'];
                $_SESSION['role']         = $user['role'];

                catatLog($koneksi, $user['id'], $username, 'sukses', $ip);

                header('Location: ' . ($user['role'] === 'admin' ? 'admin/dashboard.php' : 'index.php'));
                exit;
            }
        } else {
            $error = 'Username atau password salah.';
            catatLog($koneksi, $user['id'] ?? null, $username, 'gagal', $ip);
        }
    }
}

function catatLog($koneksi, $userId, $username, $status, $ip) {
    $stmt = $koneksi->prepare("INSERT INTO login_log (user_id, username, status, ip_address) VALUES (?, ?, ?, ?)");
    $stmt->bind_param('isss', $userId, $username, $status, $ip);
    $stmt->execute();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login - WebGIS Kabupaten Luwu</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
<style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body {
        font-family: 'Segoe UI', Arial, sans-serif;
        min-height: 100vh; display:flex; align-items:center; justify-content:center;
        background: linear-gradient(135deg, #1a3a5c 0%, #2274b8 100%);
        padding: 20px;
    }
    .login-card {
        background:#fff; border-radius:14px; width:100%; max-width:380px;
        padding: 36px 32px; box-shadow: 0 20px 60px rgba(0,0,0,0.3);
    }
    .login-logo {
        width:60px; height:60px; border-radius:50%; background:#eef6fc;
        display:flex; align-items:center; justify-content:center; margin:0 auto 16px;
    }
    .login-logo i { color:#2274b8; font-size:26px; }
    h1 { text-align:center; color:#1a3a5c; font-size:18px; margin-bottom:4px; }
    p.subtitle { text-align:center; color:#64748b; font-size:12.5px; margin-bottom:24px; }
    label { display:block; font-size:13px; font-weight:600; color:#374151; margin:14px 0 5px; }
    .input-wrap { position:relative; }
    .input-wrap i { position:absolute; left:12px; top:50%; transform:translateY(-50%); color:#94a3b8; font-size:13px; }
    input {
        width:100%; padding:11px 12px 11px 36px; border:1px solid #d1d5db;
        border-radius:8px; font-size:14px; transition: border-color .2s;
    }
    input:focus { outline:none; border-color:#2274b8; }
    button {
        width:100%; margin-top:22px; padding:12px; background:#2274b8; color:#fff;
        border:none; border-radius:8px; font-size:14.5px; font-weight:600; cursor:pointer;
        transition: background .2s;
    }
    button:hover { background:#1a5e94; }
    .alert {
        padding:10px 12px; border-radius:7px; font-size:13px; margin-bottom:6px;
        background:#fef2f2; color:#b91c1c; border:1px solid #fecaca;
    }
    .back-link { display:block; text-align:center; margin-top:18px; font-size:12.5px; color:#64748b; text-decoration:none; }
    .back-link:hover { color:#2274b8; }
</style>
</head>
<body>
    <div class="login-card">
        <div class="login-logo"><i class="fa fa-map-location-dot"></i></div>
        <h1>WebGIS Kabupaten Luwu</h1>
        <p class="subtitle">Sistem Informasi Geografis — Sulawesi Selatan</p>

        <?php if ($error): ?>
            <div class="alert"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST" action="login.php">
            <label>Username</label>
            <div class="input-wrap">
                <i class="fa fa-user"></i>
                <input type="text" name="username" required autofocus value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
            </div>

            <label>Password</label>
            <div class="input-wrap">
                <i class="fa fa-lock"></i>
                <input type="password" name="password" required>
            </div>

            <button type="submit"><i class="fa fa-right-to-bracket"></i> Masuk</button>
        </form>

        <a href="index.php?guest=1" class="back-link">Lihat sebagai tamu tanpa login &rarr;</a>
    </div>
</body>
</html>
